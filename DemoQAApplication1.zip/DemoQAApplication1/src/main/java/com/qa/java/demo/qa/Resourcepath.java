package com.qa.java.demo.qa;

public class Resourcepath {

	// Web Driver Deceleration and Its Paths

	public static final String Webdriver = "webdriver.chrome.driver";
	public static final String ChromePath = "C:\\Users\\jv18280\\eclipse-workspace\\DemoQAApplication1\\Driver\\chromedriver.exe";

	// WEB Application URL

	public static final String URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

	// ExcelPath

	public static final String Excelpath = "C:\\Users\\jv18280\\eclipse-workspace\\DemoQAApplication1\\src\\test\\java\\excel\\drt.xlsx";

	// Extent Reports Information//
	public static final String ExtenResultPath = "C:\\Users\\jv18280\\eclipse-workspace\\DemoQAApplication1\\SrceenShort\\Reports\\";

	public static final String FilePath = "C:\\Users\\jv18280\\eclipse-workspace\\DemoQAApplication1\\SrceenShort\\";
}
