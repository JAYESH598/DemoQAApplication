package com.qa.java.demo.qa;

public class Resourcepath {

	
	public static final String Webdriver="webdriver.chrome.driver";
	public static final String ChromePath ="C:\\Users\\jv18280\\eclipse-workspace\\DemoQAApplication\\Driver\\chromedriver.exe";
	
	public static final String URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	
	public static final String Excelpath = "C:\\Users\\jv18280\\eclipse-workspace\\DemoQAApplication\\src\\test\\java\\excel\\drt.xlsx";
}
